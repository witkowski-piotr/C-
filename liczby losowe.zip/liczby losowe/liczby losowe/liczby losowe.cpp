﻿// liczby losowe.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <cstdlib>
#include <time.h>
#include <stdio.h>
using namespace std;


int liczba, strzal, ile_prob=0;


int main()
{
    cout << "Witaj pomyslalem o liczbie od 1 do 100 " << endl;
    srand(time(NULL));
    liczba = rand() % 100 + 1;

    

    while (strzal!=liczba)
    {
        ile_prob++;

        cout << "Zgadnij jaka... (to twoja "<<ile_prob<<" proba ) : ";
        cin >> strzal;

        if (strzal == liczba)
        {
            cout << " Trafiles !!! Wygrywasz w "<<ile_prob<<"  probie: " << endl;

        }

        else if(strzal<liczba)
        {
            cout << " Za mało " << endl;
        }

        else if(strzal>liczba)
        {
            cout << "za duzo " << endl;
        }
        getchar();
    }

    return 0;
}


